import { type FormEvent, type ReactNode, useEffect, useMemo, useState } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  Route, Switch, useLocation, useRoute, Router as WouterRouter, Link,
} from 'wouter';
import {
  ArrowRight, ArrowUpRight, Bird, CalendarDays, Check,
  Compass, Leaf, MapPin, Menu, Mountain, Phone, Send, ShieldCheck,
  Waves, X,
} from 'lucide-react';
import HomeHeroSlideshow from '@/components/home-hero-slideshow';

const queryClient = new QueryClient();
const LOGO = '/brand/stewards-africa-safaris-logo.jpg';
const PHONE = '+256 778 903852';
const WHATSAPP = 'https://wa.me/256778903852';

type PackageDay = { title: string; place: string; text: string };
type SafariPackage = {
  slug: string; name: string; duration: string; region: string; category: string;
  image: string; imageAlt: string; intro: string; highlight: string;
  days: PackageDay[]; includes: string[]; excludes: string[];
};

const packages: SafariPackage[] = [
  {
    slug: 'gorillas-and-lakes', name: 'Gorillas & the Great Lakes', duration: '5 days / 4 nights',
    region: 'Bwindi · Lake Bunyonyi', category: 'Gorilla trekking',
    image: 'https://images.pexels.com/photos/1609551/pexels-photo-1609551.jpeg?auto=compress&cs=tinysrgb&w=1200',
    imageAlt: 'Mountain forest rising above a misty lake', intro: 'A close encounter with Bwindi’s mountain gorillas, softened by quiet time beside one of Africa’s loveliest lakes.',
    highlight: 'One unhurried gorilla trek, one lakeside exhale.',
    days: [
      { title: 'Into the highlands', place: 'Entebbe → Bwindi', text: 'Meet your local driver-guide and travel southwest through changing countryside, with a relaxed lunch stop en route.' },
      { title: 'Forest, at your own pace', place: 'Bwindi Impenetrable Forest', text: 'Brief with park rangers before your guided gorilla trek. Trek length varies with the gorilla family; return to the lodge for a well-earned evening.' },
      { title: 'The lake road', place: 'Bwindi → Lake Bunyonyi', text: 'Take the scenic highland road to Bunyonyi. Spend the afternoon on the lakeshore or opt into a locally guided canoe outing.' },
      { title: 'Islands and stories', place: 'Lake Bunyonyi', text: 'A gentle day to explore the lake and its island communities with a guide, or simply enjoy the highland air.' },
      { title: 'Return journey', place: 'Lake Bunyonyi → Entebbe', text: 'Travel back toward Entebbe with comfort stops and a final look at Uganda’s green southwest.' },
    ],
    includes: ['Private 4×4 transport with driver-guide', 'Four nights’ accommodation', 'Breakfast daily and selected meals', 'Gorilla permit arranged subject to confirmation'],
    excludes: ['International flights and visas', 'Gorilla permit fee (quoted separately)', 'Travel insurance, drinks and gratuities', 'Optional activities not listed'],
  },
  {
    slug: 'uganda-wildlife-circuit', name: 'Savannah to the Nile', duration: '7 days / 6 nights',
    region: 'Murchison Falls · Ziwa', category: 'Wildlife & nature',
    image: 'https://images.pexels.com/photos/66898/elephant-cub-tsavo-kenya-66898.jpeg?auto=compress&cs=tinysrgb&w=1200',
    imageAlt: 'Elephant walking through golden grassland', intro: 'Track rhinos on foot, scan open savannah for wildlife, then watch the Nile gather itself at Murchison Falls.',
    highlight: 'Big skies, river life, and the Nile in full voice.',
    days: [
      { title: 'A warm welcome', place: 'Entebbe → Ziwa', text: 'Settle into your private vehicle and head north. Break the journey at Ziwa Rhino Sanctuary for a guided rhino walk.' },
      { title: 'North to the Nile', place: 'Ziwa → Murchison Falls', text: 'Continue through rural Uganda to the park. Arrive in time to settle at your lodge and enjoy the landscape.' },
      { title: 'Wildlife morning', place: 'Murchison Falls National Park', text: 'Set out at first light for a guided game drive across the northern plains; return for a restful midday.' },
      { title: 'River and falls', place: 'Victoria Nile', text: 'Take a launch cruise upstream toward the base of the falls. Watch for hippos, crocodiles and abundant birdlife from the water.' },
      { title: 'Across the park', place: 'Murchison Falls National Park', text: 'Explore a different game-drive circuit with your guide, with time for a short walk to a viewpoint above the falls.' },
      { title: 'Easy morning', place: 'Murchison Falls', text: 'Choose an optional nature walk or enjoy a slow lodge morning before your second night by the Nile.' },
      { title: 'Back to Entebbe', place: 'Murchison Falls → Entebbe', text: 'Return south with a relaxed lunch stop and time to reflect on the park.' },
    ],
    includes: ['Private 4×4 transport with driver-guide', 'Six nights’ accommodation', 'Breakfast daily and selected meals', 'Park entry and planned activities, subject to final quote'],
    excludes: ['International flights and visas', 'Optional Ziwa and launch activity fees if not itemised', 'Travel insurance, drinks and gratuities', 'Personal expenses'],
  },
  {
    slug: 'primates-and-crater-lakes', name: 'Forest Neighbours', duration: '6 days / 5 nights',
    region: 'Kibale · Queen Elizabeth', category: 'Primates & wildlife',
    image: 'https://images.pexels.com/photos/247376/pexels-photo-247376.jpeg?auto=compress&cs=tinysrgb&w=1200',
    imageAlt: 'Dense tropical rainforest in the morning light', intro: 'Listen for chimpanzees in Kibale’s canopy, then trade forest shade for open savannah and crater-lake country.',
    highlight: 'Two very different worlds, one richly varied journey.',
    days: [
      { title: 'Westward', place: 'Entebbe → Fort Portal', text: 'Drive toward the Rwenzori foothills, stopping for lunch and a first view of the crater-lake landscape.' },
      { title: 'Chimpanzee forest', place: 'Kibale Forest', text: 'Join a ranger-led chimpanzee tracking walk. Spend the afternoon at leisure or arrange a community-led Bigodi Wetland walk.' },
      { title: 'Crater country', place: 'Fort Portal → Queen Elizabeth', text: 'Visit a crater-lake viewpoint before travelling south into Queen Elizabeth National Park.' },
      { title: 'Savannah day', place: 'Queen Elizabeth National Park', text: 'Take a guided game drive across the Kasenyi plains, where landscapes shift between grassland, woodland and water.' },
      { title: 'Kazinga Channel', place: 'Queen Elizabeth National Park', text: 'Enjoy a morning at leisure and an afternoon boat cruise on the Kazinga Channel, a magnet for wildlife and birds.' },
      { title: 'Return', place: 'Queen Elizabeth → Entebbe', text: 'Begin the return journey with scenic stops along the way.' },
    ],
    includes: ['Private 4×4 transport with driver-guide', 'Five nights’ accommodation', 'Breakfast daily and selected meals', 'Chimp permit coordination, subject to confirmation'],
    excludes: ['Chimpanzee permit fee (quoted separately)', 'International flights and visas', 'Optional walks and activities not listed', 'Insurance, drinks and gratuities'],
  },
  {
    slug: 'rwenzori-and-queen-elizabeth', name: 'Mountain Air & Wild Plains', duration: '8 days / 7 nights',
    region: 'Rwenzori · Queen Elizabeth', category: 'Hiking & safari',
    image: 'https://images.pexels.com/photos/1366919/pexels-photo-1366919.jpeg?auto=compress&cs=tinysrgb&w=1200',
    imageAlt: 'Dramatic mountain peaks with a cloud-wrapped ridge', intro: 'Pair a guided foothill hike in the Rwenzori region with wildlife encounters across Queen Elizabeth’s remarkable landscapes.',
    highlight: 'A rewarding walk, without needing a summit expedition.',
    days: [
      { title: 'Arrive in the west', place: 'Entebbe → Kasese', text: 'Travel west to the Rwenzori foothills, with a scenic lunch stop and a quiet first evening.' },
      { title: 'Rwenzori foothills', place: 'Rwenzori Mountains', text: 'Take a locally guided day hike through foothill scenery. Route and difficulty are tailored to conditions and your group.' },
      { title: 'A day at altitude', place: 'Kasese', text: 'Choose a second guided walk or a restorative day to enjoy the mountain setting. No technical summit climb is included.' },
      { title: 'On to the plains', place: 'Kasese → Queen Elizabeth', text: 'Drive south into the park, stopping at viewpoints over the lakes and Rift Valley.' },
      { title: 'Wildlife at first light', place: 'Queen Elizabeth National Park', text: 'Set out with your guide for a dawn game drive across the Kasenyi plains.' },
      { title: 'Birds and water', place: 'Kazinga Channel', text: 'Cruise the channel for close views of hippos, waterbirds and wildlife coming to drink.' },
      { title: 'A final safari', place: 'Queen Elizabeth National Park', text: 'Explore another park sector on a game drive, then enjoy a last sunset in the wild.' },
      { title: 'Return journey', place: 'Queen Elizabeth → Entebbe', text: 'Travel back to Entebbe at a comfortable pace.' },
    ],
    includes: ['Private 4×4 transport with driver-guide', 'Seven nights’ accommodation', 'Breakfast daily and selected meals', 'Guided non-technical foothill hike'],
    excludes: ['Technical Rwenzori summit expeditions', 'Park and activity permits unless itemised', 'International flights, visas and insurance', 'Drinks and gratuities'],
  },
];

const activities = [
  { name: 'Gorilla trekking', icon: Leaf, area: 'Bwindi Impenetrable Forest', text: 'Walk with expert park rangers through ancient forest to meet a habituated mountain gorilla family. Permit availability and fees are confirmed on inquiry.' },
  { name: 'Chimpanzee tracking', icon: Compass, area: 'Kibale Forest · Budongo', text: 'Follow the calls and movement of chimpanzees with a knowledgeable local ranger in their forest home.' },
  { name: 'Game drives', icon: Mountain, area: 'Queen Elizabeth · Murchison Falls', text: 'Explore plains and woodland with a driver-guide who reads the landscape as attentively as the tracks.' },
  { name: 'Mountain hiking', icon: Mountain, area: 'Rwenzori · Elgon · Virunga foothills', text: 'From rewarding day walks to multi-day climbs, choose a route that matches your pace and experience.' },
  { name: 'Nile white-water rafting', icon: Waves, area: 'Jinja · Source of the Nile', text: 'Ride the Nile’s famous rapids with a specialist rafting operator. Trip grade and availability depend on current conditions.' },
  { name: 'Scenic tours', icon: Compass, area: 'Across Uganda', text: 'Take the long way through highland farms, crater lakes, tea country and small roadside markets.' },
  { name: 'Birdwatching', icon: Bird, area: 'Wetlands · Forests · National parks', text: 'Explore Uganda’s rich birdlife with a specialist guide, from forest endemics to the shoebill’s papyrus habitat.' },
  { name: 'Launch cruises', icon: Waves, area: 'Kazinga Channel · Murchison Falls', text: 'See wildlife from the water on a relaxed cruise along channels and rivers alive with birds and hippos.' },
  { name: 'Sport fishing', icon: Waves, area: 'Victoria Nile · Lake Victoria', text: 'Arrange a guided fishing outing with local operators; location, tackle and permits are discussed when planning.' },
  { name: 'Photography tours', icon: Compass, area: 'Wild Uganda', text: 'Build a route around light, landscapes and wildlife behaviour, with flexible timing and a guide who knows the terrain.' },
];

function PageMeta({ title, description }: { title: string; description: string }) {
  useEffect(() => {
    document.title = `${title} | Stewards Africa Safaris`;
    const meta = document.querySelector('meta[name="description"]') ?? document.createElement('meta');
    meta.setAttribute('name', 'description'); meta.setAttribute('content', description);
    if (!meta.parentNode) document.head.appendChild(meta);
    const og = document.querySelector('meta[property="og:title"]') ?? document.createElement('meta');
    og.setAttribute('property', 'og:title'); og.setAttribute('content', `${title} | Stewards Africa Safaris`);
    if (!og.parentNode) document.head.appendChild(og);
  }, [title, description]);
  return null;
}

function ButtonLink({ href, children, secondary = false, className = '' }: { href: string; children: ReactNode; secondary?: boolean; className?: string }) {
  return <Link href={href} className={`button ${secondary ? 'button-outline' : ''} ${className}`}>{children}</Link>;
}

function Header() {
  const [open, setOpen] = useState(false);
  const [location] = useLocation();
  useEffect(() => setOpen(false), [location]);
  return (
    <header className="site-header">
      <div className="topline"><span>Locally led journeys through Uganda</span><a href={`tel:${PHONE.replaceAll(' ', '')}`} aria-label={`Call ${PHONE}`}><Phone size={13} /> {PHONE}</a></div>
      <div className="nav-shell">
        <Link href="/" className="brand" aria-label="Stewards Africa Safaris home"><img src={LOGO} alt="Stewards Africa Safaris" /></Link>
        <button className="menu-toggle" aria-label={open ? 'Close navigation menu' : 'Open navigation menu'} aria-expanded={open} onClick={() => setOpen(!open)}>{open ? <X /> : <Menu />}</button>
        <nav className={`main-nav ${open ? 'nav-open' : ''}`} aria-label="Main navigation">
          <Link href="/">Home</Link><Link href="/safaris">Safaris</Link><Link href="/activities">Activities</Link><Link href="/about">Our story</Link><Link href="/contact">Contact</Link>
          <ButtonLink href="/book" className="nav-cta">Plan your trip <ArrowUpRight size={16} /></ButtonLink>
        </nav>
      </div>
    </header>
  );
}

function Footer() {
  return <footer className="footer">
    <div className="footer-main">
      <div className="footer-brand"><img src={LOGO} alt="Stewards Africa Safaris" /><p>Good journeys begin with local knowledge. Let’s find the Uganda that feels like yours.</p></div>
      <div><p className="footer-label">Explore</p><Link href="/safaris">Our safaris</Link><Link href="/activities">Experiences</Link><Link href="/about">Our story</Link><Link href="/contact">Get in touch</Link></div>
      <div><p className="footer-label">Talk with a local</p><a href={`tel:${PHONE.replaceAll(' ', '')}`}>{PHONE}</a><p>Uganda · East Africa</p><Link href="/book" className="footer-inquiry">Start a trip inquiry <ArrowRight size={15} /></Link></div>
    </div>
    <div className="footer-bottom"><span>© {new Date().getFullYear()} Stewards Africa Safaris</span><span>Thoughtful travel, rooted in Uganda.</span><a href={WHATSAPP} target="_blank" rel="noreferrer" aria-label="WhatsApp Stewards Africa Safaris"><Phone size={15} /> WhatsApp</a></div>
  </footer>;
}

function Shell({ children }: { children: ReactNode }) {
  return <><Header/><main>{children}</main><Footer/></>;
}

function Eyebrow({ children, light = false }: { children: ReactNode; light?: boolean }) {
  return <div className={`eyebrow ${light ? 'eyebrow-light' : ''}`}><span />{children}</div>;
}

function PackageCard({ item, index = 0 }: { item: SafariPackage; index?: number }) {
  return <article className="package-card" style={{ animationDelay: `${index * 90}ms` }}>
    <Link href={`/safaris/${item.slug}`} className="package-image-link" aria-label={`Discover ${item.name}`}>
      <img src={item.image} alt={item.imageAlt} loading="lazy" /><span className="image-chip">{item.duration}</span>
    </Link>
    <div className="package-info"><div className="package-meta"><span>{item.category}</span><span><MapPin size={13}/>{item.region}</span></div>
      <h3><Link href={`/safaris/${item.slug}`}>{item.name}</Link></h3><p>{item.intro}</p>
      <Link href={`/safaris/${item.slug}`} className="text-link">Explore this journey <ArrowRight size={16}/></Link>
    </div>
  </article>;
}

function Home() {
  return <Shell>
    <PageMeta title="Uganda, closer" description="Locally grounded Uganda safaris to gorillas, wildlife, forests, mountains and the Nile. Begin a personal trip inquiry with Stewards Africa Safaris." />
    <HomeHeroSlideshow />
    <section className="intro-strip">
      <p className="strip-kicker">A different kind of safari</p>
      <p className="strip-copy">Not a checklist. A conversation with a place — shaped around your curiosity, paced by the land, and guided by people who call Uganda home.</p>
      <Link href="/about" className="text-link">Why travel with us <ArrowRight size={16}/></Link>
    </section>
    <section className="section-wrap featured-section">
      <div className="section-heading"><div><Eyebrow>Start exploring</Eyebrow><h2 className="serif">Journeys with a<br/><em>little more feeling.</em></h2></div><p>Thoughtful routes with room for the moments you didn’t plan for. Every trip can be shaped around you.</p></div>
      <div className="package-grid">{packages.slice(0, 3).map((item, i) => <PackageCard item={item} index={i} key={item.slug}/>)}</div>
      <div className="center-action"><ButtonLink href="/safaris" secondary>See all journeys <ArrowRight size={16}/></ButtonLink></div>
    </section>
    <section className="field-note">
      <div className="field-note-image"><img src="https://images.pexels.com/photos/247431/pexels-photo-247431.jpeg?auto=compress&cs=tinysrgb&w=1400" alt="Green forest canopy and a walking trail in Uganda" loading="lazy"/></div>
      <div className="field-note-copy"><Eyebrow light>Travel, with care</Eyebrow><h2 className="serif">Rooted here.<br/><em>Open to the world.</em></h2><p>We believe the best way to know a place is to move at its pace. Our local guides, trusted hosts and carefully considered routes make space for real connection — with Uganda and the people who make it.</p><ButtonLink href="/about" secondary>Our way of travelling <ArrowRight size={16}/></ButtonLink><span className="note-index">FIELD NOTE 02 / UGANDA</span></div>
    </section>
    <section className="activity-teaser">
      <div className="section-heading"><div><Eyebrow>Make it yours</Eyebrow><h2 className="serif">What calls<br/><em>you out there?</em></h2></div><p>Follow a call in the forest. Take the river. Climb into the clouds. Uganda opens up in many ways.</p></div>
      <div className="activity-pills">{activities.slice(0, 8).map((a) => <Link href="/activities" key={a.name} className="activity-pill" aria-label={a.name}>{a.name}<ArrowUpRight size={15}/></Link>)}</div>
      <Link href="/activities" className="text-link">Explore all activities <ArrowRight size={16}/></Link>
    </section>
    <section className="quote-band"><span className="quote-mark">“</span><p className="serif">The best stories are the ones that take you somewhere unexpected.</p><span className="quote-credit">A Uganda journey, your way</span></section>
    <section className="home-cta"><div><Eyebrow>Start with a conversation</Eyebrow><h2 className="serif">Tell us what<br/><em>you’re dreaming of.</em></h2><p>No fixed formula, no rush. Just a local team ready to help you make a plan.</p></div><ButtonLink href="/book">Begin a trip inquiry <ArrowRight size={17}/></ButtonLink></section>
  </Shell>;
}

function PageHero({ overline, title, subtitle, image }: { overline: string; title: React.ReactNode; subtitle: string; image?: string }) {
  return <section className={`page-hero ${image ? 'page-hero-image' : ''}`} style={image ? { backgroundImage: `linear-gradient(90deg,rgba(27,39,17,.86),rgba(27,39,17,.32)),url("${image}")` } : undefined}>
    <div className="page-hero-inner"><Eyebrow light>{overline}</Eyebrow><h1 className="serif">{title}</h1><p>{subtitle}</p></div>
  </section>;
}

function Safaris() {
  const [filter, setFilter] = useState('All journeys');
  const filters = ['All journeys', 'Gorilla trekking', 'Wildlife & nature', 'Primates & wildlife', 'Hiking & safari'];
  const shown = useMemo(() => filter === 'All journeys' ? packages : packages.filter((p) => p.category === filter), [filter]);
  return <Shell><PageMeta title="Uganda safari journeys" description="Browse locally guided Uganda safari itineraries for gorilla trekking, wildlife, chimpanzees, mountains and the Nile."/>
    <PageHero overline="Safaris, considered" title={<>The long way<br/><em>is the good way.</em></>} subtitle="A collection of journeys to get you started. Each can be tailored around your dates, pace and particular sense of wonder." image="/brand/uganda-safari-hero.jpg"/>
    <section className="section-wrap directory-section"><div className="filter-row" role="group" aria-label="Filter safaris by experience">{filters.map((f) => <button key={f} className={`filter-button ${filter === f ? 'active' : ''}`} onClick={() => setFilter(f)} aria-pressed={filter === f} data-testid={`filter-${f.toLowerCase().replaceAll(' ', '-')}`}>{f}</button>)}</div>
      <p className="results-count">{shown.length} {shown.length === 1 ? 'journey' : 'journeys'} to explore <span>·</span> All rates and permits are quote-dependent</p>
      <div className="package-grid directory-grid">{shown.map((item, i) => <PackageCard item={item} index={i} key={item.slug}/>)}</div>
      <div className="callout-inline"><div><Eyebrow>Not quite your route?</Eyebrow><h2 className="serif">We’ll help you find the thread.</h2><p>Tell us what matters most — we’ll shape a trip around it.</p></div><ButtonLink href="/book">Plan a personal journey <ArrowRight size={16}/></ButtonLink></div>
    </section>
  </Shell>;
}

function PackageDetail() {
  const [match, params] = useRoute('/safaris/:slug');
  const item = match ? packages.find((p) => p.slug === params.slug) : undefined;
  if (!item) return <NotFound />;
  return <Shell><PageMeta title={item.name} description={`${item.duration} Uganda itinerary: ${item.intro} Request a tailored trip quote with Stewards Africa Safaris.`}/>
    <section className="detail-hero" style={{ backgroundImage: `linear-gradient(90deg,rgba(22,34,15,.84),rgba(22,34,15,.2)),url("${item.image}")` }}>
      <div className="detail-hero-inner"><Link href="/safaris" className="back-link">← All safaris</Link><Eyebrow light>{item.category} · {item.region}</Eyebrow><h1 className="serif">{item.name}</h1><p>{item.intro}</p><div className="detail-stats"><span><CalendarDays size={16}/>{item.duration}</span><span><MapPin size={16}/>{item.region}</span></div><ButtonLink href={`/book?trip=${item.slug}`}>Ask about this journey <ArrowRight size={17}/></ButtonLink></div>
    </section>
    <section className="detail-body">
      <div className="itinerary-column"><Eyebrow>Your journey</Eyebrow><h2 className="serif">Day by day,<br/><em>place by place.</em></h2><div className="itinerary-list">{item.days.map((day, i) => <article className="itinerary-day" key={day.title}><div className="day-number">{String(i + 1).padStart(2, '0')}</div><div><span className="day-place">{day.place}</span><h3>{day.title}</h3><p>{day.text}</p></div></article>)}</div></div>
      <aside className="detail-aside"><div className="quote-card"><Eyebrow>At a glance</Eyebrow><p className="serif">{item.highlight}</p><span>{item.duration} · Private journey</span><ButtonLink href={`/book?trip=${item.slug}`}>Plan this trip <ArrowRight size={15}/></ButtonLink></div><div className="includes-card"><h3>What’s included</h3>{item.includes.map((x) => <p key={x}><Check size={15}/>{x}</p>)}<h3 className="exclude-title">Not included</h3>{item.excludes.map((x) => <p className="not-included" key={x}>{x}</p>)}</div><p className="quote-note">Rates, park fees and permits depend on dates, availability and your chosen level of comfort. We’ll confirm details in a written quote before any commitment.</p></aside>
    </section>
  </Shell>;
}

function Activities() {
  return <Shell><PageMeta title="Uganda activities & experiences" description="Discover gorilla trekking, chimp tracking, game drives, mountain hiking, Nile rafting, cruises, birdwatching, fishing and photography tours in Uganda."/>
    <PageHero overline="Choose your own way in" title={<>A country full<br/>of <em>ways to wander.</em></>} subtitle="From deep forest to fast water, a closer look at the experiences that make Uganda stay with you." image="https://images.pexels.com/photos/775201/pexels-photo-775201.jpeg?auto=compress&cs=tinysrgb&w=1800"/>
    <section className="section-wrap activities-section"><div className="activity-intro"><Eyebrow>Find your feeling</Eyebrow><p>Build a whole journey around one passion, or let a few different experiences find their way into the same trip. We’ll help you make it work.</p></div>
      <div className="activity-list">{activities.map((a, i) => { const Icon = a.icon; return <article className="activity-row" key={a.name}><span className="activity-number">{String(i + 1).padStart(2, '0')}</span><div className="activity-symbol"><Icon size={22}/></div><div className="activity-text"><h2>{a.name}</h2><span>{a.area}</span><p>{a.text}</p></div><Link href={`/book?activity=${encodeURIComponent(a.name)}`} className="activity-arrow" aria-label={`Ask about ${a.name}`}><ArrowUpRight size={21}/></Link></article>; })}</div>
      <div className="activity-bottom"><p>Permits, operators, seasonal conditions and rates are checked when we plan your trip.</p><ButtonLink href="/book">Ask about an activity <ArrowRight size={16}/></ButtonLink></div>
    </section>
  </Shell>;
}

function About() {
  return <Shell><PageMeta title="Our story & way of travelling" description="Meet Stewards Africa Safaris, a Uganda-based local tour operator creating personal, thoughtful safari experiences."/>
    <PageHero overline="The people behind the journey" title={<>We know the road.<br/><em>And the people on it.</em></>} subtitle="Stewards Africa Safaris is a Uganda-based team sharing the places, encounters and everyday moments that make this home." image="https://images.pexels.com/photos/3889855/pexels-photo-3889855.jpeg?auto=compress&cs=tinysrgb&w=1800"/>
    <section className="story-intro section-wrap"><Eyebrow>Our story</Eyebrow><h2 className="serif">A safari is more than<br/>the things you <em>see.</em></h2><div className="story-copy"><p>It’s the guide who spots a track before the rest of us have found our binoculars. The roadside fruit stall that becomes lunch. The stillness after a long climb, when the forest opens and the mountains appear.</p><p>We create personal journeys through Uganda with local knowledge, thoughtful pacing and care for the people and places that welcome us. There is no single right way to travel here. There is only the way that feels right for you.</p></div></section>
    <section className="values-band"><div className="values-heading"><Eyebrow light>How we travel</Eyebrow><h2 className="serif">Local by nature.<br/><em>Personal by design.</em></h2></div><div className="values-list"><article><span>01</span><div><h3>People first</h3><p>Our local guides and trusted hosts bring context, warmth and a sense of place to every day.</p></div></article><article><span>02</span><div><h3>Room to breathe</h3><p>We build in time for the unplanned moments, not just the next stop on a map.</p></div></article><article><span>03</span><div><h3>Care in the details</h3><p>We discuss expectations clearly and confirm permits, logistics and costs before you commit.</p></div></article></div></section>
    <section className="story-image-row"><img src="https://images.pexels.com/photos/1170986/pexels-photo-1170986.jpeg?auto=compress&cs=tinysrgb&w=1300" alt="A guided safari vehicle on an African landscape" loading="lazy"/><div><Eyebrow>Good journeys, well held</Eyebrow><h2 className="serif">A friendly face<br/>at every turn.</h2><p>From your first question to the last drive back, we’re here to make the moving parts feel simple — and the experience feel entirely yours.</p><ButtonLink href="/contact" secondary>Meet us in conversation <ArrowRight size={16}/></ButtonLink></div></section>
    <section className="home-cta"><div><Eyebrow>Come find out</Eyebrow><h2 className="serif">Uganda is waiting<br/><em>in its own way.</em></h2><p>Tell us what draws you here. We’ll take it from there, together.</p></div><ButtonLink href="/book">Let’s start planning <ArrowRight size={17}/></ButtonLink></section>
  </Shell>;
}

function Contact() {
  return <Shell><PageMeta title="Contact Stewards Africa Safaris" description="Speak with our Uganda-based safari team about trip planning, routes, permits and travel questions."/>
    <PageHero overline="We’re easy to find" title={<>Let’s talk<br/><em>about Uganda.</em></>} subtitle="A question, a half-formed plan, a trip you’ve been dreaming about — we’d love to hear what’s on your mind."/>
    <section className="contact-layout section-wrap"><div className="contact-copy"><Eyebrow>Get in touch</Eyebrow><h2 className="serif">Start with<br/><em>a hello.</em></h2><p>Tell us a little about what brings you to Uganda and what you’d love to experience. We’ll help you work out the next steps.</p><a className="contact-phone" href={`tel:${PHONE.replaceAll(' ', '')}`}><span className="contact-icon"><Phone size={19}/></span><span><small>Call our Uganda team</small><strong>{PHONE}</strong></span><ArrowUpRight size={18}/></a><a className="contact-phone" href={WHATSAPP} target="_blank" rel="noreferrer"><span className="contact-icon"><Send size={19}/></span><span><small>Message us on WhatsApp</small><strong>Start a conversation</strong></span><ArrowUpRight size={18}/></a><div className="contact-assurance"><ShieldCheck size={18}/><p>We’ll respond personally and help you understand the options. Rates, permits and availability are confirmed during trip planning.</p></div></div>
      <div className="contact-form-card"><Eyebrow>Or send a trip inquiry</Eyebrow><h3 className="serif">Let’s make a beginning.</h3><InquiryForm compact/></div>
    </section>
  </Shell>;
}

function InquiryForm({ compact = false, initialTrip = '', initialActivity = '' }: { compact?: boolean; initialTrip?: string; initialActivity?: string }) {
  const tripName = packages.find((p) => p.slug === initialTrip)?.name ?? '';
  const [form, setForm] = useState({ name: '', phone: '', email: '', trip: tripName || initialActivity || '', party: '2', start: '', end: '', notes: '' });
  const [errors, setErrors] = useState<Record<string, string>>({});
  const [submitted, setSubmitted] = useState(false);
  const setField = (key: string, value: string) => { setForm((v) => ({ ...v, [key]: value })); setErrors((v) => ({ ...v, [key]: '' })); setSubmitted(false); };
  const tripOptions = [...packages.map((p) => p.name), ...activities.map((a) => a.name), 'Help me choose'];
  function submit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault();
    const next: Record<string, string> = {};
    if (form.name.trim().length < 2) next.name = 'Please enter your name.';
    if (!/^[+()\d\s-]{7,}$/.test(form.phone.trim())) next.phone = 'Enter a phone number we can reach you on.';
    if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email.trim())) next.email = 'Enter a valid email address.';
    if (!form.trip) next.trip = 'Choose a trip or activity, or ask us to help you choose.';
    if (!Number.isInteger(Number(form.party)) || Number(form.party) < 1 || Number(form.party) > 20) next.party = 'Party size must be between 1 and 20.';
    if (!form.start) next.start = 'Add your preferred arrival date.';
    if (!form.end) next.end = 'Add your preferred departure date.';
    if (form.start && form.end && form.end < form.start) next.end = 'Departure should be after arrival.';
    if (Object.keys(next).length) { setErrors(next); return; }
    const text = `Hello Stewards Africa Safaris, I'd like to inquire about a Uganda trip.%0A%0AName: ${encodeURIComponent(form.name)}%0APhone: ${encodeURIComponent(form.phone)}%0AEmail: ${encodeURIComponent(form.email)}%0ASelected trip/activity: ${encodeURIComponent(form.trip)}%0AParty size: ${encodeURIComponent(form.party)}%0APreferred dates: ${encodeURIComponent(form.start)} to ${encodeURIComponent(form.end)}%0AAdditional details: ${encodeURIComponent(form.notes || 'None provided')}%0A%0AI understand this is an inquiry only; it does not confirm a reservation. Please advise on rates, permits and availability.`;
    setSubmitted(true);
    window.open(`${WHATSAPP}?text=${text}`, '_blank', 'noopener,noreferrer');
  }
  return <form className={`inquiry-form ${compact ? 'form-compact' : ''}`} onSubmit={submit} noValidate>
    <div className="form-grid"><label className="field"><span>Your name *</span><input autoComplete="name" value={form.name} onChange={(e) => setField('name', e.target.value)} placeholder="How should we address you?" aria-invalid={!!errors.name} />{errors.name && <small>{errors.name}</small>}</label>
      <label className="field"><span>Phone number *</span><input type="tel" autoComplete="tel" value={form.phone} onChange={(e) => setField('phone', e.target.value)} placeholder="+1 555 000 0000" aria-invalid={!!errors.phone}/>{errors.phone && <small>{errors.phone}</small>}</label>
      <label className="field full-field"><span>Email address *</span><input type="email" autoComplete="email" value={form.email} onChange={(e) => setField('email', e.target.value)} placeholder="you@example.com" aria-invalid={!!errors.email}/>{errors.email && <small>{errors.email}</small>}</label>
      <label className="field"><span>Trip or activity *</span><select value={form.trip} onChange={(e) => setField('trip', e.target.value)} aria-invalid={!!errors.trip}><option value="">Choose an experience</option>{tripOptions.map((x) => <option key={x} value={x}>{x}</option>)}</select>{errors.trip && <small>{errors.trip}</small>}</label>
      <label className="field"><span>Travellers *</span><select value={form.party} onChange={(e) => setField('party', e.target.value)} aria-invalid={!!errors.party}>{Array.from({ length: 20 }, (_, i) => i + 1).map((x) => <option key={x} value={x}>{x} {x === 1 ? 'traveller' : 'travellers'}</option>)}</select>{errors.party && <small>{errors.party}</small>}</label>
      <label className="field"><span>Preferred arrival *</span><input type="date" value={form.start} min={new Date().toISOString().slice(0, 10)} onChange={(e) => setField('start', e.target.value)} aria-invalid={!!errors.start}/>{errors.start && <small>{errors.start}</small>}</label>
      <label className="field"><span>Preferred departure *</span><input type="date" value={form.end} min={form.start || new Date().toISOString().slice(0, 10)} onChange={(e) => setField('end', e.target.value)} aria-invalid={!!errors.end}/>{errors.end && <small>{errors.end}</small>}</label>
      <label className="field full-field"><span>What would make this trip yours?</span><textarea value={form.notes} onChange={(e) => setField('notes', e.target.value)} rows={compact ? 3 : 4} placeholder="Interests, pace, places you have in mind…"/></label>
    </div>
    <p className="form-disclaimer">This opens a prefilled WhatsApp message to our team. Sending it is a trip inquiry only — it does not confirm a reservation or payment. Rates, permits and availability are quote-dependent.</p>
    <button className="button form-submit" type="submit">Open WhatsApp inquiry <ArrowRight size={17}/></button>
    {submitted && <p className="form-success" role="status"><Check size={16}/> Your inquiry is ready in WhatsApp. Review it and press send there to reach our team.</p>}
  </form>;
}

function Booking() {
  const params = new URLSearchParams(window.location.search);
  const trip = params.get('trip') ?? '';
  const activity = params.get('activity') ?? '';
  const [location] = useLocation();
  useEffect(() => { window.scrollTo(0, 0); }, [location]);
  return <Shell><PageMeta title="Plan a Uganda safari" description="Send Stewards Africa Safaris a trip inquiry. Share traveler details, preferred dates and a package or activity; no reservation or payment is made here."/>
    <PageHero overline="A good place to begin" title={<>Let’s plan something<br/><em>worth remembering.</em></>} subtitle="Tell us who’s coming, when you hope to travel and what you’re drawn to. We’ll take it from there — together."/>
    <section className="booking-layout section-wrap"><div className="booking-aside"><Eyebrow>Trip inquiry</Eyebrow><h2 className="serif">A few details.<br/><em>A world of possibilities.</em></h2><p>This is the first step in planning, not a confirmed booking. We’ll review your details and talk through itinerary, rates, permit requirements and availability with you.</p><div className="booking-step"><span>01</span><p><strong>Share your idea</strong><br/>Tell us what you have in mind and when you’d like to travel.</p></div><div className="booking-step"><span>02</span><p><strong>We’ll follow up</strong><br/>A local trip planner will help refine the route and options.</p></div><div className="booking-step"><span>03</span><p><strong>Confirm together</strong><br/>Nothing is reserved or charged until details are agreed separately.</p></div><a className="phone-inline" href={`tel:${PHONE.replaceAll(' ', '')}`}><Phone size={16}/> Prefer to talk? {PHONE}</a></div><div className="booking-form-card"><InquiryForm initialTrip={trip} initialActivity={activity}/></div></section>
  </Shell>;
}

function Router() {
  return <RoutedErrorBoundary><Switch>
    <Route path="/" component={Home}/><Route path="/safaris" component={Safaris}/><Route path="/safaris/:slug" component={PackageDetail}/>
    <Route path="/activities" component={Activities}/><Route path="/about" component={About}/><Route path="/contact" component={Contact}/><Route path="/book" component={Booking}/>
    <Route component={NotFound}/>
  </Switch></RoutedErrorBoundary>;
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  useEffect(() => {
    const icon = document.querySelector('link[rel="icon"]') ?? document.createElement('link');
    icon.setAttribute('rel', 'icon'); icon.setAttribute('href', LOGO); if (!icon.parentNode) document.head.appendChild(icon);
  }, []);
  return <QueryClientProvider client={queryClient}><TooltipProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}><Router/></WouterRouter><Toaster/></TooltipProvider></QueryClientProvider>;
}

export default App;
