import { useEffect, useState } from 'react';
import { ArrowRight, ChevronLeft, ChevronRight, Pause, Play } from 'lucide-react';
import { Link } from 'wouter';

const slides = [
  {
    id: 'savannah',
    image: '/brand/uganda-safari-hero.jpg',
    imageAlt: 'Elephant crossing golden savannah at sunrise',
    eyebrow: 'Uganda, seen with local eyes',
    firstLine: 'Come closer',
    accentLine: 'to the wild.',
    description:
      'From the hush of a forest before dawn to the mighty Nile in motion — find your own way into Uganda.',
    location: 'Queen Elizabeth National Park, Uganda',
    position: 'center 54%',
  },
  {
    id: 'forest',
    image:
      'https://images.pexels.com/photos/247431/pexels-photo-247431.jpeg?auto=compress&cs=tinysrgb&w=1800',
    imageAlt: 'Green forest canopy and a walking trail',
    eyebrow: 'Bwindi · guided gorilla treks',
    firstLine: 'Step into',
    accentLine: 'the forest.',
    description:
      'Move beneath the canopy and plan a guided trek to meet Uganda’s mountain gorillas.',
    location: 'Bwindi Impenetrable Forest, Uganda',
    position: 'center 52%',
  },
  {
    id: 'nile',
    image:
      'https://images.pexels.com/photos/775201/pexels-photo-775201.jpeg?auto=compress&cs=tinysrgb&w=1800',
    imageAlt: 'Adventure on a river surrounded by green landscape',
    eyebrow: 'Jinja · active days on the Nile',
    firstLine: 'Follow the river',
    accentLine: 'into adventure.',
    description:
      'Take to the water for a white-water rafting experience on the Nile near Jinja.',
    location: 'The Nile, Jinja, Uganda',
    position: 'center 52%',
  },
  {
    id: 'mountains',
    image:
      'https://images.pexels.com/photos/1366919/pexels-photo-1366919.jpeg?auto=compress&cs=tinysrgb&w=1800',
    imageAlt: 'Mountain ridge beneath low clouds',
    eyebrow: 'Rwenzori · guided foothill hikes',
    firstLine: 'Find your pace',
    accentLine: 'in the mountains.',
    description:
      'Trade the busy road for highland trails and far-reaching views on a guided Ugandan hike.',
    location: 'Rwenzori foothills, Uganda',
    position: 'center 52%',
  },
];

function prefersReducedMotion() {
  return (
    typeof window !== 'undefined' &&
    typeof window.matchMedia === 'function' &&
    window.matchMedia('(prefers-reduced-motion: reduce)').matches
  );
}

export default function HomeHeroSlideshow() {
  const [activeIndex, setActiveIndex] = useState(0);
  const [previousIndex, setPreviousIndex] = useState<number | null>(null);
  const [isTransitioning, setIsTransitioning] = useState(false);
  const [isPaused, setIsPaused] = useState(prefersReducedMotion);
  const [isHovered, setIsHovered] = useState(false);
  const [hasFocus, setHasFocus] = useState(false);
  const activeSlide = slides[activeIndex];
  const autoRotationEnabled = !isPaused && !isHovered && !hasFocus;

  const showSlide = (nextIndex: number) => {
    if (nextIndex === activeIndex) return;
    setPreviousIndex(activeIndex);
    setActiveIndex(nextIndex);
    setIsTransitioning(true);
  };

  useEffect(() => {
    if (!autoRotationEnabled) return;

    const timer = window.setInterval(() => {
      setPreviousIndex(activeIndex);
      setActiveIndex((activeIndex + 1) % slides.length);
      setIsTransitioning(true);
    }, 7200);

    return () => window.clearInterval(timer);
  }, [activeIndex, autoRotationEnabled]);

  useEffect(() => {
    if (!isTransitioning) return;

    const timer = window.setTimeout(() => {
      setPreviousIndex(null);
      setIsTransitioning(false);
    }, 1100);

    return () => window.clearTimeout(timer);
  }, [activeIndex, isTransitioning]);

  return (
    <section
      className="hero"
      role="region"
      aria-label="Featured Uganda safari experiences"
      aria-roledescription="carousel"
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
      onFocusCapture={() => setHasFocus(true)}
      onBlurCapture={(event) => {
        const nextTarget = event.relatedTarget;
        if (!(nextTarget instanceof Node) || !event.currentTarget.contains(nextTarget)) {
          setHasFocus(false);
        }
      }}
    >
      <div className="hero-visual" aria-hidden="true">
        {isTransitioning && previousIndex !== null && (
          <div
            className="hero-photo hero-photo-previous"
            style={{
              backgroundImage: `url("${slides[previousIndex].image}")`,
              backgroundPosition: slides[previousIndex].position,
            }}
          />
        )}
        <div
          key={activeSlide.id}
          className={`hero-photo hero-photo-current${isTransitioning ? ' is-transitioning' : ''}`}
          role="img"
          aria-label={activeSlide.imageAlt}
          style={{
            backgroundImage: `url("${activeSlide.image}")`,
            backgroundPosition: activeSlide.position,
          }}
        />
      </div>
      <div className="hero-shade" />
      <div className="hero-content fade-up" key={activeSlide.id}>
        <div className="eyebrow eyebrow-light"><span />{activeSlide.eyebrow}</div>
        <h1>{activeSlide.firstLine}<br/><em>{activeSlide.accentLine}</em></h1>
        <p>{activeSlide.description}</p>
        <div className="hero-actions">
          <Link href="/safaris" className="button">Find your safari <ArrowRight size={17}/></Link>
          <Link href="/about" className="button button-outline">Meet your local hosts</Link>
        </div>
      </div>
      <div className="hero-stamp" aria-hidden="true">
        <span>East Africa</span><strong>01° S<br/>32° E</strong><span>Begin here</span>
      </div>
      <div className="hero-caption">
        <div className="hero-caption-copy" aria-live={autoRotationEnabled ? 'off' : 'polite'} aria-atomic="true">
          <span>{String(activeIndex + 1).padStart(2, '0')} / {String(slides.length).padStart(2, '0')}</span>
          <span>{activeSlide.location}</span>
        </div>
        <div className="hero-carousel-controls" aria-label="Slideshow controls">
          <button
            type="button"
            className="hero-control-button"
            aria-label="Previous slide"
            data-testid="button-slide-previous"
            onClick={() => showSlide((activeIndex - 1 + slides.length) % slides.length)}
          >
            <ChevronLeft size={17}/>
          </button>
          <div className="hero-carousel-dots" aria-label="Choose a slide">
            {slides.map((slide, index) => (
              <button
                key={slide.id}
                type="button"
                className="hero-carousel-dot"
                aria-label={`Show slide ${index + 1}: ${slide.location}`}
                aria-current={activeIndex === index ? 'true' : undefined}
                data-testid={`button-slide-${slide.id}`}
                onClick={() => showSlide(index)}
              />
            ))}
          </div>
          <button
            type="button"
            className="hero-control-button"
            aria-label="Next slide"
            data-testid="button-slide-next"
            onClick={() => showSlide((activeIndex + 1) % slides.length)}
          >
            <ChevronRight size={17}/>
          </button>
          <button
            type="button"
            className="hero-control-button hero-play-toggle"
            aria-label={isPaused ? 'Play slideshow' : 'Pause slideshow'}
            aria-pressed={isPaused}
            data-testid="button-slide-play-pause"
            onClick={() => setIsPaused((paused) => !paused)}
          >
            {isPaused ? <Play size={15}/> : <Pause size={15}/>}
          </button>
        </div>
      </div>
    </section>
  );
}
